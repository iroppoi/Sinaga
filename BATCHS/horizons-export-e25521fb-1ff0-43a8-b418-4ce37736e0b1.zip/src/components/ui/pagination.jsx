
import React from 'react';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export function Pagination({ 
  total, 
  limit, 
  current, 
  onChange 
}) {
  const pages = Math.ceil(total / limit);
  
  const handlePageChange = (page) => {
    if (page >= 1 && page <= pages) {
      onChange(page);
    }
  };

  return (
    <div className="flex items-center justify-between px-2 py-4">
      <div className="flex w-[100px] items-center justify-start text-sm text-gray-500">
        Page {current} of {pages}
      </div>
      <div className="flex items-center space-x-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => handlePageChange(current - 1)}
          disabled={current <= 1}
        >
          <ChevronLeft className="h-4 w-4" />
          Previous
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => handlePageChange(current + 1)}
          disabled={current >= pages}
        >
          Next
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
      <div className="w-[100px]" />
    </div>
  );
}
