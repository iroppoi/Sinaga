
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  FileText, 
  Box, 
  Tag, 
  Palette, 
  Users, 
  Settings as SettingsIcon,
  Globe,
  ArrowRight,
  ChevronDown
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import storage from '@/lib/localStorage';

const menuItems = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/sites', icon: Globe, label: 'Sites' },
  { path: '/posts', icon: FileText, label: 'Posts' },
  { path: '/custom-posts', icon: Box, label: 'Custom Posts' },
  { path: '/taxonomies', icon: Tag, label: 'Taxonomies' },
  { path: '/themes', icon: Palette, label: 'Themes' },
  { path: '/authors', icon: Users, label: 'Authors' },
  { path: '/settings', icon: SettingsIcon, label: 'Settings' }
];

function Layout({ children }) {
  const location = useLocation();
  const { toast } = useToast();
  const currentSite = storage.get('currentSite') || { name: 'Default Site' };

  const handleSiteSwitch = () => {
    window.location.href = '/sites';
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <aside className="w-64 bg-white material-shadow">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-primary">CMS Admin</h1>
          <div className="mt-4 space-y-2">
            <div className="text-xs text-gray-500 uppercase tracking-wider">Current Site</div>
            <button
              onClick={handleSiteSwitch}
              className="w-full flex items-center justify-between p-3 bg-primary/5 rounded-lg hover:bg-primary/10 transition-colors border border-primary/20"
            >
              <div className="flex items-center space-x-3">
                <Globe className="w-5 h-5 text-primary" />
                <div className="text-left">
                  <div className="font-medium text-primary">{currentSite.name}</div>
                  <div className="text-xs text-gray-500 truncate">{currentSite.url}</div>
                </div>
              </div>
              <ChevronDown className="w-4 h-4 text-primary" />
            </button>
          </div>
        </div>
        <nav className="mt-6">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center px-6 py-3 text-gray-700 hover:bg-gray-50 ${
                  isActive ? 'bg-primary/10 border-r-4 border-primary' : ''
                }`}
              >
                <Icon className="w-5 h-5 mr-3" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-8">
        <div className="mb-6 p-4 bg-white rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <Globe className="w-4 h-4" />
            <span>Managing:</span>
            <span className="font-medium text-primary">{currentSite.name}</span>
            <span className="text-gray-400">•</span>
            <span className="text-gray-400">{currentSite.url}</span>
          </div>
        </div>
        {children}
      </main>
    </div>
  );
}

export default Layout;
