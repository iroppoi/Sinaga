
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Dashboard from '@/pages/Dashboard';
import Posts from '@/pages/Posts';
import CustomPosts from '@/pages/CustomPosts';
import Taxonomies from '@/pages/Taxonomies';
import Themes from '@/pages/Themes';
import Authors from '@/pages/Authors';
import Settings from '@/pages/Settings';
import Sites from '@/pages/Sites';
import Layout from '@/components/Layout';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/sites" element={<Sites />} />
          <Route path="/posts" element={<Posts />} />
          <Route path="/custom-posts" element={<CustomPosts />} />
          <Route path="/taxonomies" element={<Taxonomies />} />
          <Route path="/themes" element={<Themes />} />
          <Route path="/authors" element={<Authors />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </Layout>
      <Toaster />
    </Router>
  );
}

export default App;
