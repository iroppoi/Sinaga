
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Plus, Globe, Trash2, ArrowRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { dbService } from '@/lib/db';

function Sites() {
  const [sites, setSites] = useState([]);
  const [newSite, setNewSite] = useState({ name: '', url: '' });
  const { toast } = useToast();

  useEffect(() => {
    loadSites();
  }, []);

  const loadSites = async () => {
    const savedSites = await dbService.getSites();
    setSites(savedSites);
  };

  const handleAddSite = async () => {
    if (!newSite.name || !newSite.url) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    const site = { ...newSite, id: Date.now() };
    await dbService.addSite(site);
    await loadSites();
    setNewSite({ name: '', url: '' });
    
    toast({
      title: "Success",
      description: "Site added successfully",
    });
  };

  const handleDeleteSite = async (siteId) => {
    await dbService.deleteSite(siteId);
    await loadSites();
    
    toast({
      title: "Success",
      description: "Site deleted successfully",
    });
  };

  const handleSwitchSite = async (site) => {
    await dbService.setCurrentSite(site);
    toast({
      title: "Success",
      description: `Switched to ${site.name}`,
    });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Sites</h1>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Add New Site</h2>
          <div className="space-y-4">
            <div>
              <Label htmlFor="site-name">Site Name</Label>
              <Input
                id="site-name"
                value={newSite.name}
                onChange={(e) => setNewSite({ ...newSite, name: e.target.value })}
                placeholder="My New Site"
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="site-url">Site URL</Label>
              <Input
                id="site-url"
                value={newSite.url}
                onChange={(e) => setNewSite({ ...newSite, url: e.target.value })}
                placeholder="https://example.com"
                className="mt-1"
              />
            </div>
            <Button onClick={handleAddSite} className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              Add Site
            </Button>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Your Sites</h2>
          <div className="space-y-4">
            {sites.map((site) => (
              <div
                key={site.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center">
                  <Globe className="w-5 h-5 text-gray-500 mr-3" />
                  <div>
                    <h3 className="font-medium">{site.name}</h3>
                    <p className="text-sm text-gray-500">{site.url}</p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleSwitchSite(site)}
                  >
                    <ArrowRight className="w-4 h-4 mr-2" />
                    Switch
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleDeleteSite(site.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
            {sites.length === 0 && (
              <p className="text-center text-gray-500 py-4">
                No sites added yet. Add your first site above.
              </p>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}

export default Sites;
