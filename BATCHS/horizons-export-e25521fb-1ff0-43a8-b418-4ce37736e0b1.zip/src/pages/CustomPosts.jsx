
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Plus, Settings, Trash2 } from 'lucide-react';

function CustomPosts() {
  const [customPosts] = useState([
    { id: 1, name: 'Products', count: 15, fields: ['Title', 'Price', 'SKU'] },
    { id: 2, name: 'Team Members', count: 8, fields: ['Name', 'Position', 'Bio'] },
    { id: 3, name: 'Portfolio', count: 12, fields: ['Project', 'Client', 'Date'] },
  ]);

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Custom Posts</h1>
        <Button className="material-button">
          <Plus className="w-4 h-4 mr-2" />
          New Custom Post Type
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {customPosts.map((post) => (
          <Card key={post.id} className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-xl font-semibold">{post.name}</h3>
                <p className="text-sm text-gray-500">{post.count} items</p>
              </div>
              <div className="flex space-x-2">
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4" />
                </Button>
                <Button variant="destructive" size="sm">
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <p className="text-sm font-medium">Custom Fields:</p>
              <div className="flex flex-wrap gap-2">
                {post.fields.map((field, index) => (
                  <span
                    key={index}
                    className="px-2 py-1 bg-gray-100 rounded-md text-sm"
                  >
                    {field}
                  </span>
                ))}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default CustomPosts;
