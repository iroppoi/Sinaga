
import React from 'react';
import { Card } from '@/components/ui/card';
import { FileText, Box, Tag, Users } from 'lucide-react';

function Dashboard() {
  const stats = [
    { label: 'Total Posts', value: '24', icon: FileText },
    { label: 'Custom Posts', value: '8', icon: Box },
    { label: 'Taxonomies', value: '12', icon: Tag },
    { label: 'Authors', value: '6', icon: Users },
  ];

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-primary/10">
                  <Icon className="w-6 h-6 text-primary" />
                </div>
                <div className="ml-4">
                  <p className="text-sm text-gray-500">{stat.label}</p>
                  <h3 className="text-2xl font-bold">{stat.value}</h3>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Posts</h2>
          <div className="space-y-4">
            {['Latest Update', 'New Feature', 'Welcome Post'].map((post, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span>{post}</span>
                <span className="text-sm text-gray-500">2 days ago</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Activities</h2>
          <div className="space-y-4">
            {[
              'John updated a post',
              'Sarah created new taxonomy',
              'Mike changed theme settings'
            ].map((activity, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span>{activity}</span>
                <span className="text-sm text-gray-500">1 hour ago</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

export default Dashboard;
