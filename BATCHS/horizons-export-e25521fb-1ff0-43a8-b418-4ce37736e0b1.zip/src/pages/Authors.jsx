
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Plus, Edit, Trash2 } from 'lucide-react';

function Authors() {
  const [authors] = useState([
    { id: 1, name: 'John Doe', role: 'Administrator', posts: 15 },
    { id: 2, name: 'Jane Smith', role: 'Editor', posts: 8 },
    { id: 3, name: 'Mike Johnson', role: 'Author', posts: 12 },
  ]);

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Authors</h1>
        <Button className="material-button">
          <Plus className="w-4 h-4 mr-2" />
          Add Author
        </Button>
      </div>

      <Card className="p-6">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left p-4">Name</th>
                <th className="text-left p-4">Role</th>
                <th className="text-left p-4">Posts</th>
                <th className="text-right p-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {authors.map((author) => (
                <tr key={author.id} className="border-b hover:bg-gray-50">
                  <td className="p-4">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                        {author.name.charAt(0)}
                      </div>
                      {author.name}
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="px-2 py-1 rounded-full text-sm bg-blue-100 text-blue-800">
                      {author.role}
                    </span>
                  </td>
                  <td className="p-4">{author.posts} posts</td>
                  <td className="p-4">
                    <div className="flex justify-end space-x-2">
                      <Button variant="outline" size="sm">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button variant="destructive" size="sm">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

export default Authors;
