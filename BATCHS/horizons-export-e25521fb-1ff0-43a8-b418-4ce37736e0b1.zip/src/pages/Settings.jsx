
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { dbService } from '@/lib/db';

function Settings() {
  const { toast } = useToast();
  const [currentSite, setCurrentSite] = useState(null);
  const [settings, setSettings] = useState({
    siteTitle: '',
    tagline: '',
    siteUrl: '',
    adminEmail: '',
    defaultCategory: '',
    postFormat: '',
    postsPerPage: '10',
    feedSettings: '',
    permalinkStructure: '',
    categoryBase: ''
  });

  useEffect(() => {
    loadCurrentSite();
  }, []);

  useEffect(() => {
    if (currentSite) {
      loadSettings();
    }
  }, [currentSite]);

  const loadCurrentSite = async () => {
    const site = await dbService.getCurrentSite();
    setCurrentSite(site);
  };

  const loadSettings = async () => {
    if (currentSite) {
      const savedSettings = await dbService.getSettings(currentSite.id);
      setSettings(prev => ({ ...prev, ...savedSettings }));
    }
  };

  const handleSave = async () => {
    if (currentSite) {
      await dbService.updateSettings(currentSite.id, settings);
      toast({
        title: "Success",
        description: "Settings saved successfully",
      });
    }
  };

  const handleInputChange = (field, value) => {
    setSettings(prev => ({ ...prev, [field]: value }));
  };

  if (!currentSite) return null;

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Settings - {currentSite.name}</h1>

      <Card className="p-6">
        <Tabs defaultValue="general">
          <TabsList className="mb-6">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="writing">Writing</TabsTrigger>
            <TabsTrigger value="reading">Reading</TabsTrigger>
            <TabsTrigger value="permalinks">Permalinks</TabsTrigger>
          </TabsList>

          <TabsContent value="general">
            <div className="space-y-6">
              <div>
                <Label htmlFor="site-title">Site Title</Label>
                <Input
                  id="site-title"
                  className="material-input mt-2"
                  placeholder="My Awesome Site"
                  value={settings.siteTitle}
                  onChange={(e) => handleInputChange('siteTitle', e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="tagline">Tagline</Label>
                <Input
                  id="tagline"
                  className="material-input mt-2"
                  placeholder="Just another awesome website"
                  value={settings.tagline}
                  onChange={(e) => handleInputChange('tagline', e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="site-url">Site URL</Label>
                <Input
                  id="site-url"
                  className="material-input mt-2"
                  placeholder="https://example.com"
                  value={settings.siteUrl || currentSite.url}
                  onChange={(e) => handleInputChange('siteUrl', e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="admin-email">Admin Email</Label>
                <Input
                  id="admin-email"
                  type="email"
                  className="material-input mt-2"
                  placeholder="admin@example.com"
                  value={settings.adminEmail}
                  onChange={(e) => handleInputChange('adminEmail', e.target.value)}
                />
              </div>

              <Button className="material-button" onClick={handleSave}>
                Save Changes
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="writing">
            <div className="space-y-6">
              <div>
                <Label htmlFor="default-category">Default Category</Label>
                <Input
                  id="default-category"
                  className="material-input mt-2"
                  placeholder="Uncategorized"
                  value={settings.defaultCategory}
                  onChange={(e) => handleInputChange('defaultCategory', e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="post-format">Default Post Format</Label>
                <Input
                  id="post-format"
                  className="material-input mt-2"
                  placeholder="Standard"
                  value={settings.postFormat}
                  onChange={(e) => handleInputChange('postFormat', e.target.value)}
                />
              </div>

              <Button className="material-button" onClick={handleSave}>
                Save Changes
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="reading">
            <div className="space-y-6">
              <div>
                <Label htmlFor="posts-page">Posts per page</Label>
                <Input
                  id="posts-page"
                  type="number"
                  className="material-input mt-2"
                  placeholder="10"
                  value={settings.postsPerPage}
                  onChange={(e) => handleInputChange('postsPerPage', e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="feed-settings">Feed Settings</Label>
                <Input
                  id="feed-settings"
                  className="material-input mt-2"
                  placeholder="Show the most recent posts"
                  value={settings.feedSettings}
                  onChange={(e) => handleInputChange('feedSettings', e.target.value)}
                />
              </div>

              <Button className="material-button" onClick={handleSave}>
                Save Changes
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="permalinks">
            <div className="space-y-6">
              <div>
                <Label htmlFor="permalink-structure">Permalink Structure</Label>
                <Input
                  id="permalink-structure"
                  className="material-input mt-2"
                  placeholder="/post-name/"
                  value={settings.permalinkStructure}
                  onChange={(e) => handleInputChange('permalinkStructure', e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="category-base">Category Base</Label>
                <Input
                  id="category-base"
                  className="material-input mt-2"
                  placeholder="category"
                  value={settings.categoryBase}
                  onChange={(e) => handleInputChange('categoryBase', e.target.value)}
                />
              </div>

              <Button className="material-button" onClick={handleSave}>
                Save Changes
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}

export default Settings;
